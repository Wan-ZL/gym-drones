# write a A3C agent to play the game
